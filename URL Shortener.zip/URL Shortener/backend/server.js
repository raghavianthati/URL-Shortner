const express = require("express");
const cors = require("cors");

const app = express();
const PORT = 5000;

// Middleware
app.use(cors());
app.use(express.json());

// Temporary storage
const urls = {};

// Generate random short code
function generateShortCode() {
    return Math.random().toString(36).substring(2, 8);
}

// Home route
app.get("/", (req, res) => {
    res.send("URL Shortener Backend is Running!");
});

// Create short URL
app.post("/api/shorten", (req, res) => {
    const { originalUrl } = req.body;

    if (!originalUrl) {
        return res.status(400).json({
            error: "Please enter a URL"
        });
    }

    const shortCode = generateShortCode();

    urls[shortCode] = originalUrl;

    res.json({
        originalUrl: originalUrl,
        shortUrl: `http://localhost:${PORT}/${shortCode}`
    });
});

// Redirect short URL
app.get("/:shortCode", (req, res) => {
    const originalUrl = urls[req.params.shortCode];

    if (!originalUrl) {
        return res.status(404).send("Short URL not found");
    }

    res.redirect(originalUrl);
});

// Start server
app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});