async function shortenURL() {

    const urlInput = document.getElementById("urlInput");
    const result = document.getElementById("result");

    const originalUrl = urlInput.value.trim();

    if (originalUrl === "") {
        result.innerHTML = "<p>Please enter a URL.</p>";
        return;
    }

    try {

        const response = await fetch("http://localhost:5000/api/shorten", {
            method: "POST",

            headers: {
                "Content-Type": "application/json"
            },

            body: JSON.stringify({
                originalUrl: originalUrl
            })
        });

        const data = await response.json();

        if (!response.ok) {
            result.innerHTML = `<p>${data.error}</p>`;
            return;
        }

        result.innerHTML = `
            <p><strong>Your Short URL:</strong></p>

            <a href="${data.shortUrl}" target="_blank">
                ${data.shortUrl}
            </a>
        `;

    } catch (error) {

        result.innerHTML =
            "<p>Cannot connect to backend server.</p>";

        console.error(error);
    }
}